reearth.ui.show(`
<style>
  @import url('https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;500;600&family=Roboto:wght@400;500;700&display=swap');

  html,
  body {
    margin: 0;
    width: 160px;
    overflow: hidden;
  }

  #wrapper {
    box-sizing: border-box;
    background-color: #ffffff;
    padding: 12px;
    border-radius: 4px;
  }

  input {
    border: none;
    width: 180px;
    height: 20px;
    color: #141414;
    background-color: #BFBFBF;
    margin-bottom: 10px;
  }

  input::placeholder {
    font-size: 12px;
    padding-left: 4px;
  }

  label {
    display: inline-block;
    width: 55px;
  }

  #start-btn {
    padding: 4px 24px;
    display: block;
    width: 140px;
    font-weight: 500;
    color: #ffffff;
    background-color: #dd00ff;
  }
</style>

<div id="wrapper">
  <button id="start-btn"> START </button>
</div>

<script src="https://cdn.jsdelivr.net/npm/d3@7"></script>
<script src='https://unpkg.com/@turf/turf@6/turf.min.js'></script>
<script>
  let layerId;
  let reearth, cesium, property, layers;
  let newProperty;
  let resultLang = 'en';
  let newDate = new Date();
  let i = 0;
  let DataFile = [];

  const btn = document.getElementById("start-btn");




  function timeSet(item) {
    let date = new Date(item);
    let result = new Date(date + date.getTimezoneOffset())
    return result.toJSON();
  }

  let czml = [{
    id: "document",
    name: "CZML Geolocation Diagram",
    version: "1.0",
    clock: {
      interval: "1999-01-01T00:00:00.000Z/2016-01-01T14:40:00.000Z",
      currentTime: "2000-01-01T00:00:00.000Z",
      multiplier: 10518975,
    },
  },
  ]

  async function readCSV(filePath) {
    try {
      const data = await d3.csv(filePath);
      return data;
    } catch (error) {
      console.error('Error:', error);
    }
  }


  window.addEventListener("message", async function (e) {
    if (e.source !== parent) return;
    reearth = e.source.reearth;
    layers = reearth.layers.layers;
    cesium = reearth.Cesium;
    newProperty = e.data.property;

    // getting data from widget to create list uploaded images to change markers
    if (JSON.stringify(property) != JSON.stringify(newProperty)) {
      property = newProperty;
      let file = property.default.url;
      // console.log("1 file: ", file);
      readCSV(file)
        .then(data => {
          delete data.columns;
          convertLocation(data);
        })
    }
  });



  async function convertLocation(data) {
  for (const element of data) {
    if (element.hasOwnProperty("location") || element.hasOwnProperty("CityName")) {
      let addressElm = element.location || element.CityName;
      let keyword = addressElm.replace(/ |,/g, '+');
      let params = "?q=" + keyword + "&addressdetails=1&format=geojson" + '&accept-language=' + resultLang
      let apiUrl = "https://nominatim.openstreetmap.org/search" + params + "&polygon_geojson=0"
      let getCentroidPoint = "https://nominatim.openstreetmap.org/search" + params + "&polygon_geojson=0"

      console.log("getCentroidPoint", getCentroidPoint);

      try {
        const response = await fetch(getCentroidPoint);
        if (response.ok) {
          const data = await response.json();
          data.features.map(obj => {
            if (obj.properties.category === "boundary") {
              element.Lat = obj.geometry.coordinates[0];
              element.Lng = obj.geometry.coordinates[1];
            }
          });
          convertData(element);
        } else {
          throw new Error(response.statusText);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    } else {
      convertData(element);
    }
  }
}

  function convertData(element) {
    // console.log(element);
    let valid;
    if ((element.hasOwnProperty("value")) || (element.hasOwnProperty("Value"))) {
      valid = "false";
    } else {
      valid = "true";
    }

    if (valid === "true") {
      // console.log("data element: ", element);

      const { location, CityName, Lat, Lng, ...rest } = element;

      let timeSetArr = Object.keys(rest);
      let lastValue = timeSetArr[timeSetArr.length - 1];
      timeSetArr.push(lastValue)
      if (timeSetArr.length > 1) {
        timeSetArr.splice(0, 1)
      }
      // console.log(timeSetArr);

      let timeArr = Object.entries(rest);

      // console.log(rest);
      for (let i = 0; i < timeArr.length; i++) {
        const obj = {
          timeTo: timeSetArr[i] + "-12",
          timeFrom: timeArr[i][0] + "-01",
          Value: timeArr[i][1],
          lat: element.Lat,
          lng: element.Lng,
          location: element.location || element.CityName,
        }
        DataFile.push(obj)
      }
    } else {
      const obj = {
        Value: element.Value || element.value,
        lat: element.Lat,
        lng: element.Lng,
        location: element.location || element.CityName,
      }
      DataFile.push(obj)
    }
  };

  function setCZML(element) {
    i++

    let latitude = element.lat;
    let longitude = element.lng;

    let Value = element.Value.split(",").join("");
    let location = element.location;

    let Height;

    let redId = "red_" + i;
    let greenId = "green_" + i;
    let blueId = "blue_" + i;

    if (element.hasOwnProperty("timeFrom")) {
      console.log(true)

    let timeFrom = element.timeFrom;
    let timeTo = element.timeTo;

    let timeSetStr = "";
    timeSetStr = timeSet(timeFrom) + "/" + timeSet(timeTo);

    // // value small
    if (Value <= 300) {
      czml.push({
        id: greenId,
        name: "Green cylinder",
        cityName: location,
        availability: timeSetStr,
        position: {
          cartographicDegrees: [latitude, longitude, 0],
        },
        cylinder: {
          length: Value,
          topRadius: 2000,
          bottomRadius: 2000,
          material: {
            solidColor: {
              color: {
                rgba: [0, 255, 0, 255],
              },
            },
          },
          outline: false,
        },
      },
      )
    }

    // value middle
    if ((Value > 300) && (Value <= 500)) {
      let cylinderLength = Value - 300;
      Height = (300 + cylinderLength) / 2;
      czml.push({
        id: greenId,
        name: "Green cylinder",
        cityName: location,
        availability: timeSetStr,
        position: {
          cartographicDegrees: [latitude, longitude, 0],
        },
        cylinder: {
          length: 300,
          topRadius: 2000,
          bottomRadius: 2000,
          material: {
            solidColor: {
              color: {
                rgba: [0, 255, 0, 255],
              },
            },
          },
          outline: false,
        },
      },
        {
          id: redId,
          name: "Red cylinder",
          cityName: location,
          availability: timeSetStr,
          position: {
            cartographicDegrees: [latitude, longitude, Height],
          },
          cylinder: {
            length: cylinderLength,
            topRadius: 2000,
            bottomRadius: 2000,
            material: {
              solidColor: {
                color: {
                  rgba: [255, 0, 0, 255],
                },
              },
            },
            outline: false,
          },
        },
      )
    }

    //  value height
    if (Value > 500) {
      let cylinderLength = Value - 300;
      Height = (300 + cylinderLength) / 2;
      let cylinderLength2 = cylinderLength;
      let Height2 = cylinderLength2;

      czml.push({
        id: greenId,
        name: "Green cylinder",
        cityName: location,
        availability: timeSetStr,
        position: {
          cartographicDegrees: [latitude, longitude, 0],
        },
        cylinder: {
          length: 300,
          topRadius: 2000,
          bottomRadius: 2000,
          material: {
            solidColor: {
              color: {
                rgba: [0, 255, 0, 255],
              },
            },
          },
          outline: false,
        },
      },
        {
          id: redId,
          name: "Red cylinder",
          cityName: location,
          availability: timeSetStr,
          position: {
            cartographicDegrees: [latitude, longitude, Height],
          },
          cylinder: {
            length: cylinderLength,
            topRadius: 2000,
            bottomRadius: 2000,
            material: {
              solidColor: {
                color: {
                  rgba: [255, 0, 0, 255],
                },
              },
            },
            outline: false,
          },
        },
        {
          id: blueId,
          name: "Blue cylinder",
          cityName: location,
          availability: timeSetStr,
          position: {
            cartographicDegrees: [latitude, longitude, Height2],
          },
          cylinder: {
            length: cylinderLength2,
            topRadius: 2000,
            bottomRadius: 2000,
            material: {
              solidColor: {
                color: {
                  rgba: [0, 0, 255, 255],
                },
              },
            },
            outline: false,
          },
        },
      )
    }


    } else {

    // // value small
    if (Value <= 300) {
      czml.push({
        id: greenId,
        name: "Green cylinder",
        cityName: location,
        position: {
          cartographicDegrees: [latitude, longitude, 0],
        },
        cylinder: {
          length: Value,
          topRadius: 2000,
          bottomRadius: 2000,
          material: {
            solidColor: {
              color: {
                rgba: [0, 255, 0, 255],
              },
            },
          },
          outline: false,
        },
      },
      )
    }

    // value middle
    if ((Value > 300) && (Value <= 500)) {
      let cylinderLength = Value - 300;
      Height = (300 + cylinderLength) / 2;
      czml.push({
        id: greenId,
        name: "Green cylinder",
        cityName: location,
        position: {
          cartographicDegrees: [latitude, longitude, 0],
        },
        cylinder: {
          length: 300,
          topRadius: 2000,
          bottomRadius: 2000,
          material: {
            solidColor: {
              color: {
                rgba: [0, 255, 0, 255],
              },
            },
          },
          outline: false,
        },
      },
        {
          id: redId,
          name: "Red cylinder",
          cityName: location,
          position: {
            cartographicDegrees: [latitude, longitude, Height],
          },
          cylinder: {
            length: cylinderLength,
            topRadius: 2000,
            bottomRadius: 2000,
            material: {
              solidColor: {
                color: {
                  rgba: [255, 0, 0, 255],
                },
              },
            },
            outline: false,
          },
        },
      )
    }

    //  value height
    if (Value > 500) {
      let cylinderLength = Value - 300;
      Height = (300 + cylinderLength) / 2;
      let cylinderLength2 = Value - 500;
      let Height2 = Value;

      czml.push({
        id: greenId,
        name: "Green cylinder",
        cityName: location,
        position: {
          cartographicDegrees: [latitude, longitude, 0],
        },
        cylinder: {
          length: 300,
          topRadius: 2000,
          bottomRadius: 2000,
          material: {
            solidColor: {
              color: {
                rgba: [0, 255, 0, 255],
              },
            },
          },
          outline: false,
        },
      },
        {
          id: redId,
          name: "Red cylinder",
          cityName: location,
          position: {
            cartographicDegrees: [latitude, longitude, Height],
          },
          cylinder: {
            length: cylinderLength,
            topRadius: 2000,
            bottomRadius: 2000,
            material: {
              solidColor: {
                color: {
                  rgba: [255, 0, 0, 255],
                },
              },
            },
            outline: false,
          },
        },
        {
          id: blueId,
          name: "Blue cylinder",
          cityName: location,
          position: {
            cartographicDegrees: [latitude, longitude, Height2],
          },
          cylinder: {
            length: cylinderLength2,
            topRadius: 2000,
            bottomRadius: 2000,
            material: {
              solidColor: {
                color: {
                  rgba: [0, 0, 255, 255],
                },
              },
            },
            outline: false,
          },
        },
      )
    }

    }

  }

  btn.addEventListener('click', animation);

  function animation() {
    console.log(DataFile)
    DataFile.map(element => setCZML(element))

    let czmlURL = czml;
    console.log(czmlURL);
    
    layerId = reearth.layers.add({
      extensionId: "resource",
      isVisible: true,
      title: 'CZML',
      property: {
        default: {
          url: czmlURL,
          type: "czml",
          clampToGround: true
        },
      },
    });

    // reearth.camera.flyTo({
    //   lng: latitude,
    //   lat: longitude,
    //   height: 10000,
    // }, {
    //   duration: 2
    // });
  }

</script>
`);

reearth.on("update", send);
send();

function send() {
reearth.ui.postMessage({
property: reearth.widget.property,
layer: reearth.layers.layers
})
}