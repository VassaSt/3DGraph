reearth.ui.show(`
<style>
  @import url('https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;500;600&family=Roboto:wght@400;500;700&display=swap');

  html,
  body {
    margin: 0;
    width: 160px;
    overflow: hidden;
    font-family: "Roboto";
    font-size: 12px;
    font-weight: 500;
    line-height: 120%;
  }

  button {
    cursor: pointer;
    border-radius: 4px;
    border: none;
    box-shadow: 1px 1px 4px 0px rgba(124, 124, 124, 0.20);
    color: #ffffff;
    margin-bottom: 5px;
    background-color: #4c00ff;
  }

  #wrapper {
    box-sizing: border-box;
    background-color: #ffffff;
    padding: 12px;
    border-radius: 4px;
  }

  #start-btn {
    display: block;
    width: 140px;
    padding: 4px 24px;
  }

  .prop-wrap {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 5px;
  }

  #increase,
  #height {
    border: 1px solid #141414;
    width: 60%;
    height: 20px;
    color: #141414;
    background-color: #f8f8f8;
    border-radius: 4px;
  }

  input::placeholder {
    padding-left: 4px;
  }

  label {
    display: inline-block;
    font-size: 14px;
    width: 50px;
    padding-right: 5px;
  }

  .static-btn {
    display: inline-block;
    width: fit-content;
    height: 20px;
  }

  .input-wrap {
    display: flex;
    position: relative;
    height: 25px;
    border: 1px solid #c1c1c1;
    overflow: hidden;
    margin-bottom: 10px;
  }

  .input-wrap:last-of-type {
    margin-bottom: 0;
  }

  .color-input {
    display: flex;
    position: absolute;
    width: 35px;
    height: 37px;
    border: none;
    background: none;
    top: -6px;
    left: -5px;
  }

  .txt-color {
    display: flex;
    height: 25px;
    width: 50%;
    border: none;
    padding-left: 30px;
  }
</style>

<div id="wrapper">
  <button id="start-btn"> START </button>
  <div class="prop-wrap">
    <label for="increase">Scale:</label>
    <input id="increase" name="increase" type="number" placeholder="1">
  </div>
  <div class="prop-wrap">
    <label for="height">Height:</label>
    <input id="height" name="height" type="number" placeholder="">
  </div>
  <div id="colorWrap"></div>
</div>

<script src="https://cdn.jsdelivr.net/npm/d3@7"></script>
<script src='https://unpkg.com/@turf/turf@6/turf.min.js'></script>
<script>
  let reearth, cesium, property, newProperty, layers, layerId, newFile, DataFile, czml;
  let resultLang = 'en';
  let i = 0;
  let j = 0;
  let newDate = new Date();
  let green = [0, 255, 0, 255];
  let red = [255, 0, 0, 255];
  let blue = [0, 0, 255, 255];
  const btn = document.getElementById("start-btn");
  const increaseInput = document.getElementById("increase");
  const heightInput = document.getElementById("height");
  const colorInput = document.getElementById("colorInput");
  let colorWrap = document.getElementById("colorWrap");

  async function readCSV(filePath) {
    try {
      const data = await d3.csv(filePath);
      return data;
    } catch (error) {
      console.error('Error:', error);
    }
  }

  // Convert 8-digit hex colors to rgba colors
  function convertToRgbA(alphahex) {
    let hex = alphahex;
    let opacity = 255;
    // Convert each hex character pair into an integer
    let red = parseInt(hex.substring(1, 3), 16);
    let green = parseInt(hex.substring(3, 5), 16);
    let blue = parseInt(hex.substring(5, 7), 16);

    // RGBA array
    let rgba = [red, green, blue, opacity]
    return rgba
  }
 function cleanLayers(){
  czml = [{
      id: "document",
      name: "CZML Geolocation Diagram",
      version: "1.0",
    },
    ];
    let filteredLayers = layers.filter(layer => (layer.type === "resource" && layer.title === 'CZML'))
    filteredLayers.forEach(layer => {
      reearth.layers.overrideProperty(layer.id, {
        default: {
          url: []
        },
      });
    })
  }


  // clean DataFile array and czml file each time whe file is uploaded
  function cleanData() {
    document.getElementById("colorWrap").remove()
    DataFile = [];
    newFile = [];
    cleanLayers();
  }

  function timeSet(item) {
    let date = new Date(item);
    // let result = new Date(date + date.getTimezoneOffset())
    return date.toJSON();
  }

  window.addEventListener("message", async function (e) {
    if (e.source !== parent) return;
    reearth = e.source.reearth;
    layers = reearth.layers.layers;
    cesium = reearth.Cesium;
    newProperty = e.data.property;

    // getting data from widget to create list uploaded images to change markers
    if (JSON.stringify(property) != JSON.stringify(newProperty)) {
      property = newProperty;
      let file = property.default.url;
      cleanData();
      readCSV(file)
        .then(data => {
          delete data.columns;
          newFile = data;
          crateUI(newFile[1])
        })
    }
  });

  function crateUI(arr) {
    const { location, CityName, Lat, Lng, value, Value, ...rest } = arr;
    let timeSetArr = Object.keys(rest);
    let k = 0;

    let colorWrap = document.createElement('div');
    colorWrap.id = "colorWrap";
    document.getElementById("wrapper").appendChild(colorWrap);

    if (timeSetArr.length > 0) {
      timeSetArr.map(element => {
        let name = element;
        // console.log(name);
        uiObj(name, k)
      }
      )
    } else {
      let name = "Color";
      uiObj(name, k)
    }

    function uiObj(name) {
      k++
      let colorInputName = "color-input__" + k;
      let txtForColorId = "colorTxt" + k;

      let colorLabel = document.createElement('label');
      colorLabel.setAttribute("for", colorInputName);
      colorLabel.textContent = name + ":";

      let staticBtn = document.createElement('button');
      staticBtn.classList.add("static-btn");
      staticBtn.setAttribute("type", "button");
      staticBtn.setAttribute("value", name);
      staticBtn.textContent = "Static";
      staticBtn.setAttribute("onclick", "functionStaticCZML()")

      let inputWrap = document.createElement('div');
      inputWrap.classList.add('input-wrap');

      let colorInput = document.createElement('input');
      colorInput.classList.add('color-input');
      colorInput.id = name;
      colorInput.setAttribute("name", colorInputName);
      colorInput.setAttribute("type", "color");
      colorInput.setAttribute("value", "#2bff00");

      let txtForColor = document.createElement('input');
      txtForColor.classList.add('txt-color');
      txtForColor.setAttribute('type', 'text');
      txtForColor.id = txtForColorId;
      txtForColor.setAttribute('value', "#2bff00");

      colorWrap.appendChild(colorLabel);
      colorWrap.appendChild(staticBtn);
      colorWrap.appendChild(inputWrap);
      inputWrap.appendChild(colorInput);
      inputWrap.appendChild(txtForColor);

    }
  }

  function fileObject(Value, Lat, Lng, location, colorName) {
    let result = {
      Value: Value,
      Lat: Lat,
      Lng: Lng,
      location: location,
      colorInputId: colorName,
    }
    return result
  }

  function time(timeFrom, timeTo) {
    let timeToMinusDay = new Date(timeTo);
    timeToMinusDay.setDate(timeToMinusDay.getDate() - 1);
    timeToMinusDay.setHours(timeToMinusDay.getHours() + 23);
    timeToMinusDay.setMinutes(timeToMinusDay.getMinutes() + 59);
    let timeSetStr = "";
    timeSetStr = timeSet(timeFrom) + "/" + timeToMinusDay.toJSON();
    return timeSetStr;
  };

  function czmlObject(objId, colorName, location, latitude, longitude, height, radius, Value, color) {
    let result = {
      id: objId,
      name: colorName + "cylinder",
      cityName: location,
      position: {
        cartographicDegrees: [latitude, longitude, height],
      },
      cylinder: {
        length: Value,
        topRadius: radius,
        bottomRadius: radius,
        material: {
          solidColor: {
            color: {
              rgba: color,
            },
          },
        },
        outline: false,
      },
    }
    return result
  }


  // get coordinates data by the name
  async function convertLocation(data) {
    console.log(newFile);
    console.log(DataFile);
    czml = [{
      id: "document",
      name: "CZML Geolocation Diagram",
      version: "1.0",
    },
    ];
    for (const element of data) {
      if (element.hasOwnProperty("location") || element.hasOwnProperty("CityName")) {
        let addressElm = element.location || element.CityName;
        let keyword = addressElm.replace(/ |,/g, '+');
        let params = "?q=" + keyword + "&addressdetails=1&format=geojson" + '&accept-language=' + resultLang
        let apiUrl = "https://nominatim.openstreetmap.org/search" + params + "&polygon_geojson=0"
        let getCentroidPoint = "https://nominatim.openstreetmap.org/search" + params + "&polygon_geojson=0"
        // console.log("getCentroidPoint", getCentroidPoint);

        try {
          const response = await fetch(getCentroidPoint);
          if (response.ok) {
            const data = await response.json();
            data.features.map(obj => {
              if (obj.properties.category === "boundary") {
                element.Lat = obj.geometry.coordinates[0];
                element.Lng = obj.geometry.coordinates[1];
              }
            });
          } else {
            throw new Error(response.statusText);
          }
        } catch (error) {
          console.error("Error fetching data:", error);
        }
      }
    }
    return data
  }

  // convert data for convinion json file
  function convertData(element) {
    if ((element.hasOwnProperty("value")) || (element.hasOwnProperty("Value"))) {
      // object without time availability
      let Value = element.value || element.Value;
      let location = element.location || element.CityName;
      obj = fileObject(Value, element.Lat, element.Lng, location, "Color")
      DataFile.push(obj)
    } else {
      // get time and values from each element (for each location point)
      const { location, CityName, Lat, Lng, ...rest } = element;
      let timeSetArr = Object.keys(rest);
      // create one more date to finish animation
      let lastValue = timeSetArr[timeSetArr.length - 1];
      lastValue = Number(lastValue) + 1;
      lastValue = lastValue.toString();
      timeSetArr.push(lastValue)

      // add multiplayer time availability czml file (clock):　get first and last time dates
      if (czml[0].hasOwnProperty("clock") === false) {
        czml[0].clock = {
          interval: timeSet(timeSetArr[0]) + "/" + timeSet(timeSetArr[timeSetArr.length - 1]),
          currentTime: timeSet(timeSetArr[0]),
          multiplier: 10518975,
        }
      }

      if (timeSetArr.length > 1) {
        timeSetArr.splice(0, 1)
      }
      //object with time availability
      let timeArr = Object.entries(rest);
      for (let i = 0; i < timeArr.length; i++) {
        Value = timeArr[i][1];
        timeFrom = timeArr[i][0];
        timeTo = timeSetArr[i];
        let location = element.location || element.CityName;
        let colorName = timeArr[i][0];
        obj = fileObject(Value, element.Lat, element.Lng, location, colorName);
        obj.time = time(timeFrom, timeTo)
        DataFile.push(obj)
      }
    }
  };


  function setCZML(element) {
    // console.log(element);
    i++
    let latitude = element.Lat;
    let longitude = element.Lng;

    // increase all parametrs
    let increaseNum = increaseInput.value || 1;
    let radius = 1000 * increaseNum;
    let Value = (element.Value.split(",").join("")) * increaseNum;

    let location = element.location;

    let labelObj = {
      text: location,
      font: "12px sans-serif",
      showBackground: false,
      horizontalOrigin: "LEFT",
      style: "FILL_AND_OUTLINE",
      outlineWidth: 2,
      pixelOffset: {
        cartesian2: [20, 0],
      },
    }

    let objId = "Id_" + i;
    let colorID = element.colorInputId;

    let colorRGBA = document.getElementById(colorID).value;
    let color = convertToRgbA(colorRGBA)
// console.log(color);

    let obj;

    let colorName = "Dinamic_"

    obj = czmlObject(objId, colorName, location, latitude, longitude, 0, radius, Value, color);
    if (element.hasOwnProperty("time")) {
      obj.availability = element.time;
    }
    obj.label = labelObj;
    czml.push(obj)
  }

  btn.addEventListener('click', animation);

  function animation() {

    if (DataFile.length == 0){
      console.log("lenth 0 DataFile: ", 0);
      convertLocation(newFile)
      .then(data => {
        data.map(element => convertData(element))
      })
      .then(data => {
        console.log("widget DataFile: ", DataFile);
        DataFile.map(element => setCZML(element))
        czmlInLayer(czml)
      })
    } else {
      cleanLayers()
      console.log("widget DataFile: ", DataFile);
        DataFile.map(element => setCZML(element))
        czmlInLayer(czml)
    }
  }



  function setStaticCZML(element) {
      j++
      let latitude = element.Lat;
      let longitude = element.Lng;

      // increase all parametrs
      let increaseNum = increaseInput.value || 1;
      let smallValue = 500 * increaseNum;
      let middleValue = 1000 * increaseNum;
      let radius = 1000 * increaseNum;


      let Value = (element.Value.split(",").join("")) * increaseNum;

      let cylinderLength = Value - smallValue;
      let Height = Value / 2;
      let cylinderLength2 = Value - cylinderLength;
      let Height2 = Value;

      let location = element.location;
      let greenId = "green_" + j;
      let redId = "red_" + j;
      let blueId = "blue_" + j;
      let labelObj = {
        text: location,
        font: "12px sans-serif",
        showBackground: false,
        horizontalOrigin: "LEFT",
        style: "FILL_AND_OUTLINE",
        outlineWidth: 2,
        pixelOffset: {
          cartesian2: [20, 0],
        },
      }

      let obj;

      // value small
      if (Value <= smallValue) {
        obj = czmlObject(greenId, "Green_", location, latitude, longitude, 0, radius, Value, green);
        obj.label = labelObj
        czml.push(obj);
      }

      // value middle
      if ((Value > smallValue) && (Value <= middleValue)) {
        obj = czmlObject(greenId, "Green_", location, latitude, longitude, 0, radius, smallValue, green);
        obj.label = labelObj
        let obj2 = czmlObject(redId, "Red_", location, latitude, longitude, Height, radius, cylinderLength, red);
        // obj2.label = labelObj
        czml.push(obj, obj2);
      }

      //  value height
      if (Value > middleValue) {
        obj = czmlObject(greenId, "Green_", location, latitude, longitude, 0, radius, smallValue, green);
        obj.label = labelObj
        let obj2 = czmlObject(redId, "Red_", location, latitude, longitude, Height, radius, cylinderLength, red);
        let obj3 = czmlObject(blueId, "Blue_", location, latitude, longitude, Height2, radius, cylinderLength2, blue);
        // obj3.label = labelObj
        czml.push(obj, obj2, obj3);
      }

    }

  function functionStaticCZML() {
    
    cleanLayers()

    // console.log("setStaticCZML newFile: ", newFile);
  
    let keyDate = event.target.value;
    
    if (DataFile.length == 0){
      convertLocation(newFile)
      .then(data => {
        data.map(element => convertData(element))
        console.log("1 setStaticCZML DataFile: ", DataFile);
      })
      .then(data => {
        // let DataFile = data
        DataFile.map(element =>  {
          if (element.colorInputId === keyDate) {
            // console.log("colorInputId",  element.colorInputId);
            console.log("2 DataFile element: ", element);
            setStaticCZML(element)
          }
        })
        console.log(czml);
        czmlInLayer(czml)
      })
    } else {
      DataFile.map(element =>  {
        if (element.colorInputId === keyDate) {
          // console.log("colorInputId",  element.colorInputId);
          setStaticCZML(element)
        }
      })
      console.log(czml);
        czmlInLayer(czml)
    }



  }


  function czmlInLayer(czml) {
      console.log(czml)
      if (layerId) {
          // console.log(layerId)
          reearth.layers.overrideProperty(layerId, {
            default: {
              url: czml
            },
          })
        } else {
          layerId = reearth.layers.add({
            extensionId: "resource",
            isVisible: true,
            title: 'CZML',
            property: {
              default: {
                url: czml,
                type: "czml",
                clampToGround: true
              },
            },
          });
        }

        let latitude = czml[1].position.cartographicDegrees[0];
        let longitude = czml[1].position.cartographicDegrees[1];

        reearth.camera.flyTo({
          lng: latitude,
          lat: longitude,
          height: 50000,
        }, {
          duration: 2
        });
    }

</script>
`);

reearth.on("update", send);
send();

function send() {
reearth.ui.postMessage({
property: reearth.widget.property,
layer: reearth.layers.layers
})
}