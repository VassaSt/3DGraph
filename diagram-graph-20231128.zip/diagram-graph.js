reearth.ui.show(`
<style>
  @import url('https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;500;600&family=Roboto:wght@400;500;700&display=swap');

  html,
  body {
    margin: 0;
    width: 300px;
    height: 70px;
    overflow: hidden;
  }

  #wrapper {
    box-sizing: border-box;
    background-color: #e6e6e6;
    padding: 4px;
  }

  input {
    border: none;
    width: 180px;
    height: 20px;
    color: #141414;
    background-color: #BFBFBF;
    margin-bottom: 10px;
  }

  input::placeholder {
    font-size: 12px;
    padding-left: 4px;
  }
</style>

<div id="wrapper">
  <input type="text" id="search-input">
  <input type="text" id="value-input">
  <button id="search-btn" class="cursor-btn"> Search </button>
</div>

<script src='https://unpkg.com/@turf/turf@6/turf.min.js'></script>
<script>
  let czml;
  let layerId
  let reearth, cesium, property, layers;
  let resultLang = 'en'
  let centroid = []
  let centroidArr = []

const searchBtn = document.getElementById("search-btn");


  // document.getElementById("search-btn").addEventListener('click', searchByLocationName);


  window.addEventListener("message", async function (e) {
    if (e.source !== parent) return;

    reearth = e.source.reearth;
    layers = reearth.layers.layers;
    cesium = reearth.Cesium;

    searchBtn.addEventListener('click', function searchByLocationName() {
    let addressElm = document.getElementById("search-input");
    let valueElm = document.getElementById("value-input");
    let keyword = addressElm.value.replace(/ |,/g, '+');
    let params = "?q=" + keyword + "&addressdetails=1&format=geojson" + '&accept-language=' + resultLang
    let apiUrl = "https://nominatim.openstreetmap.org/search" + params + "&polygon_geojson=0"
    let getCentroidPoint = "https://nominatim.openstreetmap.org/search" + params + "&polygon_geojson=0"

    // console.log("getCentroidPoint", getCentroidPoint);

    fetch(getCentroidPoint).then(response => {
      if (response.ok) {
        response.json().then(data => {
          console.log("data: ", data);

          data.features.map(obj => {
            if (obj.properties.category === "boundary") {
              centroid.push(obj.geometry.coordinates)
              centroidArr.push({
                placeId: obj.properties["place_id"],
                centroid: obj.geometry.coordinates,
                value: valueElm.value,
              })
            }
          })
          setCZML(centroidArr);
          console.log("centroidArr", centroidArr);
        })
      } else {
        throw new Error(response.statusText);
      }
    })
  }
);
  });


  function setCZML(centroidArr) {
let i = 0;
let czmlId = i++
    
    if (centroidArr.length > 0) {
      centroidArr.map((element) => {
console.log(element);
      let Lat = element.centroid[0];
      let Lng = element.centroid[1];
      let Value = (element.value) * 10;
      let Value2 = Value * 2; 
      let Value3 = Value * 3; 
      let timeLine = "2023-11-23T00:00:00Z/2023-11-24T24:00:00Z";
      let timeLine2 =  "2023-11-25T00:00:00Z/2023-11-26T24:00:00Z";
      let timeLine3 = "2023-11-27T00:00:00Z/2023-11-28T24:00:00Z";
  
      let czmlId = [
    {
      id: "document",
      name: "CZML Geometries: Cones and Cylinders",
      version: "1.0",
    },
    {
      id: "shape1",
      name: "Green cylinder",
      availability: timeLine,
      position: {
        cartographicDegrees: [Lat, Lng, 0],
      },
      cylinder: {
        length: Value,
        topRadius: 2000,
        bottomRadius: 2000,
        material: {
          solidColor: {
            color: {
              rgba: [0, 255, 0, 255],
            },
          },
        },
        outline: false,
      },
    },
    {
      id: "shape2",
      name: "Red cylinder",
      availability: timeLine2,
      position: {
        cartographicDegrees: [Lat, Lng, 0],
      },
      cylinder: {
        length: Value2,
        topRadius: 2000,
        bottomRadius: 2000,
        material: {
          solidColor: {
            color: {
              rgba: [255, 0, 0, 255],
            },
          },
        },
      },
    },
     {
      id: "shape3",
      name: "yellow cylinder",
       availability: timeLine3,
      position: {
        cartographicDegrees: [Lat, Lng, 0],
      },
      cylinder: {
        length: Value3,
        topRadius: 2000,
        bottomRadius: 2000,
        material: {
          solidColor: {
            color: {
              rgba: [255, 255, 0, 255],
            },
          },
        },
      },
    },
  ];
  
  
      layerId = reearth.layers.add({
        extensionId: "resource",
        isVisible: true,
        title: 'CZML',
        property: {
          default: {
            url: czmlId,
            type: "czml",
            clampToGround: true
          },
        },
      });
  
      reearth.camera.flyTo({
        lng: Lat,
        lat: Lng,
        height: Value3,
      }, {
        duration: 2
      });
    })
    }
  }


</script>
`);

reearth.on("update", send);
send();

function send() {
  reearth.ui.postMessage({
    layer: reearth.layers.layers
  })
}