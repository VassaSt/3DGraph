reearth.ui.show(`
<style>
  @import url('https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;500;600&family=Roboto:wght@400;500;700&display=swap');

  html,
  body {
    margin: 0;
    width: 160px;
    overflow: hidden;
  }

  #wrapper {
    box-sizing: border-box;
    background-color: #ffffff;
    padding: 12px;
    border-radius: 4px;
  }

  input {
    border: none;
    width: 180px;
    height: 20px;
    color: #141414;
    background-color: #BFBFBF;
    margin-bottom: 10px;
  }

  input::placeholder {
    font-size: 12px;
    padding-left: 4px;
  }

  label {
    display: inline-block;
    width: 55px;
  }

  #start-btn {
    padding: 4px 24px;
    display: block;
    width: 140px;
    font-weight: 500;
    color: #ffffff;
    background-color: #dd00ff;
  }

  #increase{
    display: inline-block;
    width: 100%;
  }
</style>

<div id="wrapper">
  <button id="start-btn"> START </button>
  <form action="">
    <label for="increase">Scale:</label>
    <input id="increase" name="increase" type="number" placeholder="1">
  </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/d3@7"></script>
<script src='https://unpkg.com/@turf/turf@6/turf.min.js'></script>
<script>
  let reearth, cesium, property, newProperty, layers, layerId, DataFile, czml;
  let resultLang = 'en';
  let i = 0;
  let green = [0, 255, 0, 255];
  let red = [255, 0, 0, 255];
  let blue = [0, 0, 255, 255];
  let newDate = new Date();
  const btn = document.getElementById("start-btn");
  const increase = document.getElementById("increase");

  function timeSet(item) {
    let date = new Date(item);
    // let result = new Date(date + date.getTimezoneOffset())
    return date.toJSON();
  }

  async function readCSV(filePath) {
    try {
      const data = await d3.csv(filePath);
      return data;
    } catch (error) {
      console.error('Error:', error);
    }
  }

  // clean DataFile array and czml file each time whe file is uploaded
  function cleanData() {
    DataFile = [];
    czml = [{
      id: "document",
      name: "CZML Geolocation Diagram",
      version: "1.0",
    },
    ]
    // TO DO: clean layers
  }

  window.addEventListener("message", async function (e) {
    if (e.source !== parent) return;
    reearth = e.source.reearth;
    layers = reearth.layers.layers;
    cesium = reearth.Cesium;
    newProperty = e.data.property;

    // getting data from widget to create list uploaded images to change markers
    if (JSON.stringify(property) != JSON.stringify(newProperty)) {
      property = newProperty;
      let file = property.default.url;
      // console.log("1 file: ", file);
      cleanData();
      readCSV(file)
        .then(data => {
          delete data.columns;
          convertLocation(data);
        })
    }
  });

  // get coordinates data by the name
  async function convertLocation(data) {
    for (const element of data) {
      if (element.hasOwnProperty("location") || element.hasOwnProperty("CityName")) {
        let addressElm = element.location || element.CityName;
        let keyword = addressElm.replace(/ |,/g, '+');
        let params = "?q=" + keyword + "&addressdetails=1&format=geojson" + '&accept-language=' + resultLang
        let apiUrl = "https://nominatim.openstreetmap.org/search" + params + "&polygon_geojson=0"
        let getCentroidPoint = "https://nominatim.openstreetmap.org/search" + params + "&polygon_geojson=0"
        // console.log("getCentroidPoint", getCentroidPoint);

        try {
          const response = await fetch(getCentroidPoint);
          if (response.ok) {
            const data = await response.json();
            data.features.map(obj => {
              if (obj.properties.category === "boundary") {
                element.Lat = obj.geometry.coordinates[0];
                element.Lng = obj.geometry.coordinates[1];
              }
            });
          } else {
            throw new Error(response.statusText);
          }
        } catch (error) {
          console.error("Error fetching data:", error);
        }
      }
      convertData(element);
    }
  }

  // convert data for convinion json file
  function convertData(element) {
    // console.log(element);
    let obj, Value, timeFrom, timeTo;

    // basic object
    function Base() { }
    Base.prototype.base = function () {
      this.Value = Value;
      this.lat = element.Lat;
      this.lng = element.Lng;
      this.location = element.location || element.CityName;
    }

    // sub object if csv file consist fron time values 
    // convert date to JSON format to time string for availability in czml file (for anomation) 
    function SubObj() { }
    SubObj.prototype = Object.create(Base.prototype)
    SubObj.prototype.constructor = SubObj;
    SubObj.prototype.time = function () {
      let timeToMinusDay = new Date(timeTo);
      timeToMinusDay.setDate(timeToMinusDay.getDate() - 1);
      timeToMinusDay.setHours(timeToMinusDay.getHours() + 23);
      timeToMinusDay.setMinutes(timeToMinusDay.getMinutes() + 59);
      let timeSetStr = "";
      timeSetStr = timeSet(timeFrom) + "/" + timeToMinusDay.toJSON();
      this.time = timeSetStr;
    };


    if ((element.hasOwnProperty("value")) || (element.hasOwnProperty("Value"))) {
      // basic object without time availability
      Value = element.Value || element.value;
      obj = new Base(Value);
      obj.base()
      DataFile.push(obj)
    } else {
      // get time and values from each element (for each location point)
      const { location, CityName, Lat, Lng, ...rest } = element;
      let timeSetArr = Object.keys(rest);
      // create one more date to finish animation
      let lastValue = timeSetArr[timeSetArr.length - 1];
      lastValue = Number(lastValue) + 1;
      lastValue = lastValue.toString();
      timeSetArr.push(lastValue)

      // add multiplayer time availability czml file (clock):　get first and last time dates
      if (czml[0].hasOwnProperty("clock") === false) {
        czml[0].clock = {
          interval: timeSet(timeSetArr[0]) + "/" + timeSet(timeSetArr[timeSetArr.length - 1]),
          currentTime: timeSet(timeSetArr[0]),
          multiplier: 10518975,
        }
      }

      if (timeSetArr.length > 1) {
        timeSetArr.splice(0, 1)
      }

      // sub object with time availability
      let timeArr = Object.entries(rest);
      for (let i = 0; i < timeArr.length; i++) {
        Value = timeArr[i][1];
        timeFrom = timeArr[i][0];
        timeTo = timeSetArr[i];
        obj = new SubObj(Value, timeFrom, timeTo);
        obj.base()
        obj.time()
        DataFile.push(obj)
      }
    }
  };


  function setCZML(element) {
    i++
    let latitude = element.lat;
    let longitude = element.lng;

    // increase all parametrs
    let increaseNum = increase.value || 1;
    let smallValue = 300 * increaseNum;
    let middleValue = 500 * increaseNum;
    let radius = 1000 * increaseNum;
    let Value = (element.Value.split(",").join("")) * increaseNum;

    let cylinderLength = Value - smallValue;
    let Height = Value / 2;
    let cylinderLength2 = Value - cylinderLength;
    let Height2 = Value;
    
    let location = element.location;
    let greenId = "green_" + i;
    let redId = "red_" + i;
    let blueId = "blue_" + i;
    let labelObj = {
      text: location,
      font: "12px sans-serif",
      showBackground: false,
      horizontalOrigin: "LEFT",
      style: "FILL_AND_OUTLINE",
      outlineWidth: 2,
      pixelOffset: {
        cartesian2: [20, 0],
      },
    }



    let obj, objId, colorName, height, color;

    function czmlObject(objId, colorName, height, Value, color) {
      let result = {
        id: objId,
        name: colorName + "cylinder",
        cityName: location,
        position: {
          cartographicDegrees: [latitude, longitude, height],
        },
        cylinder: {
          length: Value,
          topRadius: radius,
          bottomRadius: radius,
          material: {
            solidColor: {
              color: {
                rgba: color,
              },
            },
          },
          outline: false,
        },
      }
      return result
    }


    // czml file with time animation
    if (element.hasOwnProperty("time")) {
      let timeSetStr = element.time;

      // value small
      if (Value <= smallValue) {
        obj = czmlObject(greenId, "Green_", 0, Value, green);
        obj.availability = timeSetStr;
        obj.label = labelObj
        czml.push(obj)
      }

      // value middle
      if ((Value > smallValue) && (Value <= middleValue)) {
        obj = czmlObject(greenId, "Green_", 0, smallValue, green);
        obj.availability = timeSetStr;
        obj.label = labelObj
        let obj2 = czmlObject(redId, "Red_", Height, cylinderLength, red);
        obj2.availability = timeSetStr;
        czml.push(obj, obj2);
      }

      //  value height
      if (Value > middleValue) {
        obj = czmlObject(greenId, "Green_", 0, smallValue, green);
        obj.availability = timeSetStr;
        obj.label = labelObj
        let obj2 = czmlObject(redId, "Red_", Height, cylinderLength, red);
        obj2.availability = timeSetStr;
        let obj3 = czmlObject(blueId, "Blue_", Height2, cylinderLength2, blue);
        obj3.availability = timeSetStr;
        czml.push(obj, obj2, obj3);
      }

    } else {
      // czml file without time

      // value small
      if (Value <= smallValue) {
        obj = czmlObject(greenId, "Green_", 0, Value, green);
        obj.label = labelObj
        czml.push(obj);
      }

      // value middle
      if ((Value > smallValue) && (Value <= middleValue)) {
        obj = czmlObject(greenId, "Green_", 0, smallValue, green);
        obj.label = labelObj
        let obj2 = czmlObject(redId, "Red_", Height, cylinderLength, red);
        czml.push(obj, obj2);
      }

      //  value height
      if (Value > middleValue) {
        obj = czmlObject(greenId, "Green_", 0, smallValue, green);
        obj.label = labelObj
        let obj2 = czmlObject(redId, "Red_", Height, cylinderLength, red);
        let obj3 = czmlObject(blueId, "Blue_", Height2, cylinderLength2, blue);
        czml.push(obj, obj2, obj3);
      }
    }
  }

  btn.addEventListener('click', animation);
  function animation() {
    // console.log("DataFile: ", DataFile);
    DataFile.map(element => setCZML(element))

    console.log(czml);
    let latitude = czml[1].position.cartographicDegrees[0];
    let longitude = czml[1].position.cartographicDegrees[1];

    layerId = reearth.layers.add({
      extensionId: "resource",
      isVisible: true,
      title: 'CZML',
      property: {
        default: {
          url: czml,
          type: "czml",
          clampToGround: true
        },
      },
    });

    reearth.camera.flyTo({
      lng: latitude,
      lat: longitude,
      height: 50000,
    }, {
      duration: 2
    });
  }

</script>
`);

reearth.on("update", send);
send();

function send() {
reearth.ui.postMessage({
property: reearth.widget.property,
layer: reearth.layers.layers
})
}