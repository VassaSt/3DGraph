reearth.ui.show(`
<style>
  @import url('https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;500;600&family=Roboto:wght@400;500;700&display=swap');

  html,
  body {
    margin: 0;
    width: 300px;
    overflow: hidden;
  }

  #wrapper {
    box-sizing: border-box;
    background-color: #ffffff;
    padding: 12px;
    border-radius: 4px;
  }

  input {
    border: none;
    width: 180px;
    height: 20px;
    color: #141414;
    background-color: #BFBFBF;
    margin-bottom: 10px;
  }

  input::placeholder {
    font-size: 12px;
    padding-left: 4px;
  }

  label {
    display: inline-block;
    width: 55px;
  }

  #search-btn {
    padding: 4px 24px;
    display: block;
    width: 140px;
    font-weight: 500;
    color: #ffffff;
    background-color: #dd00ff;
  }
</style>

<div id="wrapper">
  <!-- <input type="text" id="search-input">
  <input type="text" id="value-input">
  <div>
    <label for="year-from">FROM: </label>
    <input type="text" id="year-from">
  </div>
  <div>
    <label for="year-to">TO: </label>
    <input type="text" id="year-to">
  </div> -->
  <button id="search-btn" class=""> START </button>
</div>

<script src='https://unpkg.com/@turf/turf@6/turf.min.js'></script>
<script>
  let layerId;
  let reearth, cesium, property, layers;
  let resultLang = 'en';
  let newDate = new Date();
  let i = 0;

  function timeSet(item) {
    console.log("item: ", item);
    console.log("diff: ", item.getTimezoneOffset());
    let result = new Date(item + item.getTimezoneOffset())
    console.log(result.toJSON());
    return result.toJSON();
    // return item.toJSON();
  }



  const btn = document.getElementById("search-btn");

  let DataFile = [
    {
      location: "Japan Himeji",
      value: "225",
      timeFrom: "2023 11 26",
      timeTo: "2023 11 27",
    },
    {
      location: "Japan Himeji",
      value: "375",
      timeFrom: "2023 11 27",
      timeTo: "2023 11 30",
    },
    {
      location: "Japan Kobe",
      value: "750",
      timeFrom: "2023 11 25",
      timeTo: "2023 11 27",
    },
    {
      location: "Japan Kobe",
      value: "285",
      timeFrom: "2023 11 27",
      timeTo: "2023 11 29",
    },
    {
      location: "Japan Osaka",
      value: "225",
      timeFrom: "2023 11 25",
      timeTo: "2023 11 27",
    },
    {
      location: "Japan Osaka",
      value: "375",
      timeFrom: "2023 11 27",
      timeTo: "2023 11 29",
    },
    {
      location: "Japan Osaka",
      value: "546",
      timeFrom: "2023 11 29",
      timeTo: "2023 11 30",
    },
  ];

  window.addEventListener("message", async function (e) {
    if (e.source !== parent) return;
    reearth = e.source.reearth;
    layers = reearth.layers.layers;
    cesium = reearth.Cesium;
  });

  btn.addEventListener('click', function searchByLocationName() {
    console.log("DataFile: ", DataFile);

    DataFile.map((element) => {
      i++
      let addressElm = element.location;
      let keyword = addressElm.replace(/ |,/g, '+');
      let params = "?q=" + keyword + "&addressdetails=1&format=geojson" + '&accept-language=' + resultLang
      let apiUrl = "https://nominatim.openstreetmap.org/search" + params + "&polygon_geojson=0"
      let getCentroidPoint = "https://nominatim.openstreetmap.org/search" + params + "&polygon_geojson=0"

      // console.log("getCentroidPoint", getCentroidPoint);

      fetch(getCentroidPoint).then(response => {
        if (response.ok) {
          response.json().then(data => {
            console.log("data: ", data);

            data.features.map(obj => {
              if (obj.properties.category === "boundary") {
                element.placeId = obj.properties["place_id"];
                element.centroid = obj.geometry.coordinates;
              }
            })
            setCZML(element);
            console.log("element", element);
          })
        } else {
          throw new Error(response.statusText);
        }
      })
    })
  });

  let czml = [{
    id: "document",
    name: "CZML Geolocation Diagram",
    version: "1.0",
    clock: {
            interval: "2023-11-25T00:00:00Z/" + newDate.toJSON(),
            currentTime: "2023-11-24T00:00:00Z",
            multiplier: 2400,
            },
  },]

  function setCZML(element) {
    console.log("element in setCZML: ", element);
    let Lat = element.centroid[0];
    let Lng = element.centroid[1];
    let Height;
    let Value = (element.value);
    let placeId = element.placeId;
    let timeFromValue = element.timeFrom;
    let timeToValue = element.timeTo;
    let timeFrom = new Date(timeFromValue);
    let timeTo = new Date(timeToValue);
    let redId = "red_" + i;
    let greenId = "green_" + i;
    let blueId = "blue_" + i;
    console.log("FROM :", timeSet(timeFrom));
    console.log("TO: ", timeSet(timeTo));

    // value small
    if (Value <= 300) {
      czml.push({
        id: greenId,
        name: "Green cylinder",
        availability: timeSet(timeFrom) + "/" + timeSet(timeTo),
        position: {
          cartographicDegrees: [Lat, Lng, 0],
        },
        cylinder: {
          length: Value,
          topRadius: 2000,
          bottomRadius: 2000,
          material: {
            solidColor: {
              color: {
                rgba: [0, 255, 0, 255],
              },
            },
          },
          outline: false,
        },
      },
      )
    }

    // value middle
    if ((Value > 300) && (Value <= 500)) {
      // if (Value > 300 ) {
      let cylinderLength = Value - 300;
      Height = (300 + cylinderLength) / 2;
      czml.push({
        id: greenId,
        name: "Green cylinder",
        availability: timeSet(timeFrom) + "/" + timeSet(timeTo),
        position: {
          cartographicDegrees: [Lat, Lng, 0],
        },
        cylinder: {
          length: 300,
          topRadius: 2000,
          bottomRadius: 2000,
          material: {
            solidColor: {
              color: {
                rgba: [0, 255, 0, 255],
              },
            },
          },
          outline: false,
        },
      },
        {
          id: redId,
          name: "Red cylinder",
          availability: timeSet(timeFrom) + "/" + timeSet(timeTo),
          position: {
            cartographicDegrees: [Lat, Lng, Height],
          },
          cylinder: {
            length: cylinderLength,
            topRadius: 2000,
            bottomRadius: 2000,
            material: {
              solidColor: {
                color: {
                  rgba: [255, 0, 0, 255],
                },
              },
            },
            outline: false,
          },
        },
      )
    }

    // //  value height
    if (Value > 500) {
      let cylinderLength = Value - 300;
      Height = (300 + cylinderLength) / 2;
      let cylinderLength2 = Value - cylinderLength;
      let Height2 = 300 + cylinderLength;
      czml.push({
        id: greenId,
        name: "Green cylinder",
        availability: timeSet(timeFrom) + "/" + timeSet(timeTo),
        position: {
          cartographicDegrees: [Lat, Lng, 0],
        },
        cylinder: {
          length: 300,
          topRadius: 2000,
          bottomRadius: 2000,
          material: {
            solidColor: {
              color: {
                rgba: [0, 255, 0, 255],
              },
            },
          },
          outline: false,
        },
      },
        {
          id: redId,
          name: "Red cylinder",
          availability: timeSet(timeFrom) + "/" + timeSet(timeTo),
          position: {
            cartographicDegrees: [Lat, Lng, Height],
          },
          cylinder: {
            length: cylinderLength,
            topRadius: 2000,
            bottomRadius: 2000,
            material: {
              solidColor: {
                color: {
                  rgba: [255, 0, 0, 255],
                },
              },
            },
            outline: false,
          },
        },
        {
          id: blueId,
          name: "Blue cylinder",
          availability: timeSet(timeFrom) + "/" + timeSet(timeTo),
          position: {
            cartographicDegrees: [Lat, Lng, Height2],
          },
          cylinder: {
            length: cylinderLength2,
            topRadius: 2000,
            bottomRadius: 2000,
            material: {
              solidColor: {
                color: {
                  rgba: [0, 0, 255, 255],
                },
              },
            },
            outline: false,
          },
        },
      )
    }

    console.log("czml object: ", czml);


    layerId = reearth.layers.add({
      extensionId: "resource",
      isVisible: true,
      title: 'CZML',
      property: {
        default: {
          url: czml,
          type: "czml",
          clampToGround: true
        },
      },
    });

    reearth.camera.flyTo({
      lng: Lat,
      lat: Lng,
      height: 10000,
    }, {
      duration: 2
    });

  }

</script>
`);

reearth.on("update", send);
send();

function send() {
reearth.ui.postMessage({
layer: reearth.layers.layers
})
}